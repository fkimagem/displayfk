#define DISP_DEFAULT
#define TOUCH_GSL3680
#define USE_TOUCH