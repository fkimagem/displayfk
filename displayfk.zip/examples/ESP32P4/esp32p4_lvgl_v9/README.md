# 请使用arduino_esp32_v3.1版本

#请将lvgl文件夹中的demo文件夹移动至src文件夹中