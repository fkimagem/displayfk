# Display FK
This library is a HAL that allow you to use many widgtes based on display library ArduinoGFX version 1.5.9 from `moononournation`

[https://github.com/moononournation/Arduino_GFX]

## How to Use
1. Download all the files and unzip them.
2. Go to your `libraries` folder in the Arduino IDE (portable or Documents installation).
3. Create a new folder named `DisplayFK` and paste all the unzipped files into that folder.
4. Open your Arduino IDE (if it is already open, close and reopen it), go to **File > Examples > DisplayFK** and check that the examples are listed.